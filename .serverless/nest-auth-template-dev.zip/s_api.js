
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'pisanggoreng',
  applicationName: 'nest-auth-template',
  appUid: 'Plhx68Fh6b7gYJqc80',
  orgUid: 'z4dR7PspSYDTqdnd5B',
  deploymentUid: '429bd3b2-fdc5-4e4f-8c7e-340a7df6d6c3',
  serviceName: 'nest-auth-template-dev',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.2',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'nest-auth-template-dev-dev-api', timeout: 6 };

try {
  const userHandler = require('./dist/lambda.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}